/*
project name: class10ds
program:endzero
Author: Erik Bailey
Date: Nov 7 2020
Synoposis: 
puts values of zero at end of array
*/
package class10ds;
public class endzero {
    public int[] back(int[] yr,int zeros){
        for(int i=0;i<yr.length;i++){
            if((yr[i]==0)&&(i<999)){
                yr[i]=yr[i+1];
                yr[i+1]=0;
            }
        }
        if(zeros>0){
            return back(yr,zeros-1);
        }
        return yr;
    }
    public int example(int x)
    {
        if(x<=0){
        return 1;
        }
        else{
            System.out.println("test");
        return x*example(x-1);
        }
        }      
    
}
/*
        for(int i=0;i<yr.length;i++){
            if((yr[i]==0)&&(i<9)){
            //    System.out.println(yr[i]+"i"+i);
                yr[i]=yr[i+1];
                yr[i+1]=0;
            }
        }

*/
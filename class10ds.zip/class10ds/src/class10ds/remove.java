/*
project name: class10ds
program:remove
Author: Erik Bailey
Date: Nov 7 2020
Synoposis: 
removes values from array
*/
package class10ds;

import java.util.Arrays;

public class remove {
    public int[] rem(int[] yr, int start){
        String s;
        multiply m = new multiply();
        int r=start;//will be changed based on another class
        int times=1;
        int out =0;//number of zeros in array
        while(r<1001){
            times=times+1;
            for(int i=0;i<yr.length;i++){
                if((yr[i]==r)&&(yr[i]!=start)){
                    out=out+1;
                    yr[i]=0;
//                    System.out.println(r);
                }
            }
            r=m.out(start, times);
        }
//        s=Arrays.toString(yr);
        endzero ez =new endzero();
        ez.back(yr,out);
        s=Arrays.toString(yr);
//        System.out.println(s);

        return yr;
    }
}









//need to adjust array to have all zeros at end not just one 
// remember recursion
/*
project name: class10ds
program:makearray
Author: Erik Bailey
Date: Nov 7 2020
Synoposis: 
makes array with 1000 values
*/
package class10ds;

import java.util.Arrays;

public class makearray {
    public int[] yar(){//values 0 to 999 are 2 to 1001
        int yar[] = new int[1000];
        int yr[] = new int[1000];
        String s;
      //  s=Arrays.toString(yr);
        //System.out.println(s);
        for(int i=0;i<yar.length;i++){
            yar[i]=i+2;
        }
        yr=yar;
        s=Arrays.toString(yr);
        System.out.println("original "+s);
        remove r = new remove();
        multiply m = new multiply();
//        m.out(yr,multiplier, times);
        for(int i =0;i<=100;i++){
        r.rem(yr, i+2);
        //s=Arrays.toString(yr);
     //   System.out.println("new "+s);
        }
        for(int i =100;i<yr.length;i++){
            yr[i]=0;
        }
//        r.rem(yr, 3);
        s=Arrays.toString(yr);
        System.out.println("new "+s);
        
        return yar;
    }
}

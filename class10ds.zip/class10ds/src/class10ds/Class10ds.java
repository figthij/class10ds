/*
project name: class10ds
program:class10ds
Author: Erik Bailey
Date: Nov 7 2020
Synoposis: 
finds first 100 prime numbers using eratosthenes
must use recursion
should be able to only use one array
*/
package class10ds;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Class10ds {
    public static void main(String[] args) {
        //search for value
        makearray ma = new makearray();
        ma.yar();
        
    }
    
}

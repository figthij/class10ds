/*
project name: class10ds
program:multiply
Author: Erik Bailey
Date: Nov 7 2020
Synoposis: 
determines what values to be removed
*/
package class10ds;
public class multiply {
    public int out(int multiplier, int times){
        int out;
        out=multiplier*times;
        return out;
        
    }
}
